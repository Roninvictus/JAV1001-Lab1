

fun main() {
    //always declare before starting if statement
    //for accepting user input i.e nullibles
    var x = 2 + 2  // ?: says print 0 if null,
    if (x == 3) {
        println("x is 3")
    }
 else if (x == 2) {
                println("x is 2")
 } else {
     println("x is neither 2 or 3")
    }
}
