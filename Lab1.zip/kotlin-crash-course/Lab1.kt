/*Victor Yusuf
* A00254959
* Mobile Applications Development
*/


fun main() {
    println("Input numeric value:")
    val value = readLine()!!.toDouble()
    println("Input measurement unit  (km, mi, kg, lb, C, F, K):")
    val unit = readLine()!!
    val result = when (unit) {
        "km" -> value * 0.62
        "mi" -> value / 0.62
        "kg" -> value * 2.2
        "lb" -> value / 2.2
        "C" -> (value * (9/5)) + 32
        "F" -> (value - 32) * (5/9)
        "K" -> value - 273.15
        else -> value
    }
    println("Result: $result $unit")
}
